-- MicroNetworks full schema (Supabase / Postgres)

-- PROFILES: one per auth user
create table if not exists profiles (
  id uuid primary key, -- matches auth.user.id
  username text unique,
  display_name text,
  microbux_balance integer not null default 0,
  created_at timestamptz default now()
);

-- ACCOUNTS: posting identities (main + proxy)
create table if not exists accounts (
  id uuid primary key default gen_random_uuid(),
  owner_profile_id uuid not null references profiles(id) on delete cascade,
  type text not null check (type in ('main', 'proxy')),
  proxy_type text check (proxy_type in ('government','business')),
  username text not null unique,
  display_name text,
  bio text,
  avatar_config jsonb,
  profile_picture_url text,
  verification_status text not null default 'none'
    check (verification_status in ('none','personal','government','business')),
  created_at timestamptz default now()
);

-- ACTIVE ACCOUNT per profile
create table if not exists active_accounts (
  owner_profile_id uuid primary key references profiles(id) on delete cascade,
  active_account_id uuid not null references accounts(id) on delete cascade,
  updated_at timestamptz default now()
);

-- VERIFICATION REQUESTS for proxy accounts
create table if not exists verification_requests (
  id bigserial primary key,
  account_id uuid not null references accounts(id) on delete cascade,
  requested_type text not null check (requested_type in ('government','business')),
  status text not null default 'pending' check (status in ('pending','approved','denied')),
  submitted_at timestamptz default now(),
  reviewed_at timestamptz,
  admin_id uuid references profiles(id),
  admin_note text
);

-- ITEMS: catalog entries (R/UR/LR)
create table if not exists items (
  id bigserial primary key,
  name text not null,
  description text,
  slot text not null,
  rarity text not null check (rarity in ('R','UR','LR')),
  price_microbux integer not null check (price_microbux >= 0),
  image_url text,
  created_at timestamptz default now()
);

-- USER ITEMS: inventory ownership
create table if not exists user_items (
  ownership_id bigserial primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  item_id bigint not null references items(id) on delete cascade,
  acquired_at timestamptz default now()
);

-- POSTS
create table if not exists posts (
  id bigserial primary key,
  author_account_id uuid not null references accounts(id) on delete cascade,
  content text not null,
  created_at timestamptz default now()
);

-- FOLLOWS
create table if not exists follows (
  id bigserial primary key,
  follower_account_id uuid not null references accounts(id) on delete cascade,
  following_account_id uuid not null references accounts(id) on delete cascade,
  created_at timestamptz default now(),
  unique (follower_account_id, following_account_id)
);

-- MESSAGES
create table if not exists messages (
  id bigserial primary key,
  sender_account_id uuid not null references accounts(id) on delete cascade,
  receiver_account_id uuid not null references accounts(id) on delete cascade,
  content text not null,
  created_at timestamptz default now(),
  read_at timestamptz
);

-- NOTIFICATIONS
create table if not exists notifications (
  id bigserial primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  data jsonb,
  is_read boolean default false,
  created_at timestamptz default now()
);

-- MARKET LISTINGS
create table if not exists market_listings (
  id bigserial primary key,
  ownership_id bigint not null references user_items(ownership_id) on delete cascade,
  seller_user_id uuid not null references profiles(id) on delete cascade,
  price_microbux integer not null check (price_microbux > 0),
  created_at timestamptz default now(),
  active boolean not null default true
);

-- TRADE OFFERS
create table if not exists trade_offers (
  id bigserial primary key,
  from_user_id uuid not null references profiles(id) on delete cascade,
  to_user_id uuid not null references profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','cancelled')),
  created_at timestamptz default now(),
  decided_at timestamptz
);

-- Items offered in a trade (many-to-many)
create table if not exists trade_items (
  id bigserial primary key,
  trade_id bigint not null references trade_offers(id) on delete cascade,
  ownership_id bigint not null references user_items(ownership_id) on delete cascade,
  side text not null check (side in ('from','to')) -- which side is giving this item
);

-- DAILY REWARDS
create table if not exists daily_rewards (
  id bigserial primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  last_claimed_at timestamptz,
  streak integer not null default 0
);

-- ECONOMY LOG
create table if not exists microbux_transactions (
  id bigserial primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  amount integer not null,
  reason text,
  created_at timestamptz default now()
);
