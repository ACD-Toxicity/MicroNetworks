"use client";

import { useEffect, useRef, useState } from "react";

export default function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/notifications");
        const data = await res.json();
        setNotifications(data.notifications || []);
        setUnreadCount(
          (data.notifications || []).filter((n: any) => !n.is_read).length
        );
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, []);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  async function markAllRead() {
    try {
      await fetch("/api/notifications/markAllRead", { method: "POST" });
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (e) {
      console.error(e);
    }
  }

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen((o) => !o)}
        style={{
          position: "relative",
          padding: 6,
          borderRadius: "999px",
          background: "transparent",
          border: "none",
          cursor: "pointer"
        }}
      >
        <span role="img" aria-label="bell">
          🔔
        </span>
        {unreadCount > 0 && (
          <span
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              transform: "translate(30%,-30%)",
              background: "#dc2626",
              color: "white",
              borderRadius: "999px",
              padding: "0 4px",
              fontSize: 10
            }}
          >
            {unreadCount}
          </span>
        )}
      </button>
      {open && (
        <div
          style={{
            position: "absolute",
            right: 0,
            marginTop: 8,
            width: 320,
            background: "#020617",
            border: "1px solid rgba(30,64,175,0.7)",
            borderRadius: 12,
            boxShadow: "0 10px 40px rgba(15,23,42,0.8)",
            zIndex: 50
          }}
        >
          <div
            style={{
              padding: "6px 10px",
              borderBottom: "1px solid rgba(30,64,175,0.7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              fontSize: 12
            }}
          >
            <span>Notifications</span>
            <button
              onClick={markAllRead}
              style={{
                background: "transparent",
                border: "none",
                color: "#60a5fa",
                fontSize: 10,
                cursor: "pointer"
              }}
            >
              Mark all read
            </button>
          </div>
          <div style={{ maxHeight: 260, overflowY: "auto" }}>
            {notifications.length === 0 ? (
              <p style={{ fontSize: 12, padding: 8, color: "#9ca3af" }}>
                No notifications.
              </p>
            ) : (
              notifications.map((n) => (
                <div
                  key={n.id}
                  style={{
                    padding: 8,
                    fontSize: 12,
                    background: n.is_read ? "transparent" : "rgba(30,64,175,0.25)"
                  }}
                >
                  {n.message}
                  <div style={{ fontSize: 10, color: "#6b7280" }}>
                    {new Date(n.created_at).toLocaleString()}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
