export function VerificationBadge({
  status,
  size = 14
}: {
  status: "none" | "personal" | "government" | "business";
  size?: number;
}) {
  if (!status || status === "none") return null;

  let bg = "";
  if (status === "personal") bg = "background:#30c95a;";
  if (status === "government") bg = "background:#bcbcbc;";
  if (status === "business") bg = "background:#e7c744;";

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: "999px",
        width: size,
        height: size,
        fontSize: 10,
        color: "#fff",
        ...(bg ? { background: bg.replace("background:", "") } : {})
      }}
    >
      ✓
    </span>
  );
}
