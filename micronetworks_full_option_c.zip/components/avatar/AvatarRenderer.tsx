type AvatarConfig = {
  base?: string | null;
  eyes?: string | null;
  mouth?: string | null;
  hair_back?: string | null;
  hair_front?: string | null;
  shirt?: string | null;
  pants?: string | null;
  accessory1?: string | null;
  accessory2?: string | null;
  back?: string | null;
  effect?: string | null;
};

export function AvatarRenderer({
  account,
  size = 96
}: {
  account: any;
  size?: number;
}) {
  if (!account) return null;

  if (account.type === "proxy") {
    const letter =
      account.display_name?.[0] ||
      account.username?.[0] ||
      "?";

    return (
      <div
        style={{
          width: size,
          height: size,
          borderRadius: "999px",
          overflow: "hidden",
          background: "#0A1027",
          border: "1px solid rgba(59,130,246,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: size * 0.4
        }}
      >
        {account.profile_picture_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={account.profile_picture_url}
            alt={account.display_name || account.username}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        ) : (
          <span>{letter}</span>
        )}
      </div>
    );
  }

  const cfg: AvatarConfig = account.avatar_config || {};
  const layers: (keyof AvatarConfig)[] = [
    "base",
    "eyes",
    "mouth",
    "hair_back",
    "shirt",
    "pants",
    "accessory1",
    "accessory2",
    "back",
    "hair_front",
    "effect"
  ];

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 16,
        overflow: "hidden",
        border: "1px solid rgba(30,64,175,0.7)",
        position: "relative",
        background: "#050816"
      }}
    >
      {layers.map((slot) => {
        const src = cfg[slot];
        if (!src) return null;
        // eslint-disable-next-line @next/next/no-img-element
        return (
          <img
            key={slot}
            src={src}
            alt={String(slot)}
            style={{
              position: "absolute",
              inset: 0,
              width: "100%",
              height: "100%",
              objectFit: "contain",
              pointerEvents: "none"
            }}
          />
        );
      })}
    </div>
  );
}
