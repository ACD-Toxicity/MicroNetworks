"use client";

import { useEffect, useRef, useState } from "react";
import { AvatarRenderer } from "./avatar/AvatarRenderer";
import { VerificationBadge } from "./VerificationBadge";

async function switchAccountAction(id: string) {
  const res = await fetch("/api/accounts/switch", {
    method: "POST",
    body: JSON.stringify({ accountId: id })
  });
  return res.json();
}

export default function AccountSwitcher() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/accounts/me");
        const data = await res.json();
        setAccounts(data.accounts || []);
        setActiveId(data.activeAccountId || null);
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, []);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  if (!accounts.length) return null;

  const active = accounts.find((a) => a.id === activeId) || accounts[0];

  async function handleSwitch(id: string) {
    const res = await switchAccountAction(id);
    if (!res.error) {
      setActiveId(id);
      window.location.reload();
    }
  }

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen((o) => !o)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "4px 10px",
          borderRadius: 999,
          background: "#020617",
          border: "1px solid rgba(30,64,175,0.7)",
          fontSize: 12,
          cursor: "pointer"
        }}
      >
        <AvatarRenderer account={active} size={28} />
        <span>@{active.username}</span>
        <VerificationBadge status={active.verification_status} />
      </button>
      {open && (
        <div
          style={{
            position: "absolute",
            right: 0,
            marginTop: 8,
            width: 260,
            background: "#020617",
            border: "1px solid rgba(30,64,175,0.7)",
            borderRadius: 12,
            boxShadow: "0 10px 40px rgba(15,23,42,0.9)",
            zIndex: 50,
            padding: 6
          }}
        >
          {accounts.map((acc) => (
            <button
              key={acc.id}
              onClick={() => handleSwitch(acc.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                width: "100%",
                padding: 6,
                borderRadius: 8,
                border: "none",
                background:
                  acc.id === activeId ? "rgba(30,64,175,0.5)" : "transparent",
                cursor: "pointer"
              }}
            >
              <AvatarRenderer account={acc} size={30} />
              <div style={{ flex: 1, textAlign: "left" }}>
                <div style={{ fontSize: 12, fontWeight: 600 }}>
                  @{acc.username}
                </div>
                <div style={{ fontSize: 10, color: "#9ca3af" }}>
                  {acc.type === "main" ? "Personal account" : "Proxy account"}
                </div>
              </div>
              <VerificationBadge status={acc.verification_status} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
