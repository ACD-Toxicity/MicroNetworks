import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const userId = String(body.userId || "");
  const amount = Number(body.amount || 0);
  const reason = String(body.reason || "Admin grant");

  if (!userId || !amount) {
    return NextResponse.json({ error: "Missing fields." });
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("microbux_balance")
    .eq("id", userId)
    .single();

  if (!profile) return NextResponse.json({ error: "Profile not found." });

  await supabase
    .from("profiles")
    .update({ microbux_balance: profile.microbux_balance + amount })
    .eq("id", userId);

  await supabase.from("microbux_transactions").insert({
    user_id: userId,
    amount,
    reason
  });

  return NextResponse.json({ success: true });
}
