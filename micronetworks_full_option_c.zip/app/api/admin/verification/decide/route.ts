import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const id = Number(body.id);
  const decision = String(body.decision || "");

  if (!id || !["approved","denied"].includes(decision)) {
    return NextResponse.json({ error: "Invalid data." });
  }

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: reqRow } = await supabase
    .from("verification_requests")
    .select("*")
    .eq("id", id)
    .single();

  if (!reqRow) return NextResponse.json({ error: "Request not found." });

  const { error: updErr } = await supabase
    .from("verification_requests")
    .update({
      status: decision,
      reviewed_at: new Date().toISOString(),
      admin_id: user.id
    })
    .eq("id", id);

  if (updErr) return NextResponse.json({ error: "Update failed." });

  if (decision === "approved") {
    const newStatus = reqRow.requested_type === "government" ? "government" : "business";
    await supabase
      .from("accounts")
      .update({ verification_status: newStatus })
      .eq("id", reqRow.account_id);
  }

  return NextResponse.json({ success: true });
}
