import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ requests: [] });

  const { data } = await supabase
    .from("verification_requests")
    .select("*, account:accounts(username)")
    .eq("status", "pending")
    .order("submitted_at", { ascending: true });

  return NextResponse.json({ requests: data || [] });
}
