import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const id = body.id as number;
  const approve = !!body.approve;

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  // TODO: check admin role

  const { data: reqRow } = await supabase
    .from("verification_requests")
    .select("*")
    .eq("id", id)
    .single();

  if (!reqRow || reqRow.status !== "pending") {
    return NextResponse.json({ error: "Invalid request." });
  }

  const newStatus = approve ? "approved" : "denied";

  await supabase
    .from("verification_requests")
    .update({
      status: newStatus,
      reviewed_at: new Date().toISOString(),
      admin_id: user.id
    })
    .eq("id", id);

  if (approve) {
    const badge = reqRow.requested_type === "government" ? "government" : "business";
    await supabase
      .from("accounts")
      .update({ verification_status: badge, proxy_type: reqRow.requested_type })
      .eq("id", reqRow.account_id);
  }

  return NextResponse.json({ success: true });
}
