import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const name = String(body.name || "").trim();
  const slot = String(body.slot || "").trim();
  const rarity = String(body.rarity || "").trim();
  const price = Number(body.price_microbux || 0);
  const image_url = String(body.image_url || "").trim();

  if (!name || !slot || !rarity || !price || !image_url) {
    return NextResponse.json({ error: "Missing fields." });
  }

  const { error } = await supabase.from("items").insert({
    name,
    slot,
    rarity,
    price_microbux: price,
    image_url
  });

  if (error) return NextResponse.json({ error: "Failed to create item." });

  return NextResponse.json({ success: true });
}
