import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const accountId = String(body.accountId || "");
  const displayName = String(body.displayName || "");
  const bio = String(body.bio || "");
  const profilePictureUrl = body.profilePictureUrl || null;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: acc } = await supabase
    .from("accounts")
    .select("id, owner_profile_id, type")
    .eq("id", accountId)
    .single();

  if (!acc || acc.owner_profile_id !== user.id) {
    return NextResponse.json({ error: "You do not own this account." });
  }

  const patch: any = {
    display_name: displayName,
    bio
  };

  if (acc.type === "proxy") {
    patch.profile_picture_url = profilePictureUrl;
  }

  const { error } = await supabase
    .from("accounts")
    .update(patch)
    .eq("id", accountId);

  if (error) return NextResponse.json({ error: "Failed to update." });

  return NextResponse.json({ success: true });
}
