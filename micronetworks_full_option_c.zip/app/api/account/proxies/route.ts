import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ proxies: [], profile: null });

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  const { data: proxies } = await supabase
    .from("accounts")
    .select("*")
    .eq("owner_profile_id", user.id)
    .eq("type", "proxy")
    .order("created_at", { ascending: true });

  return NextResponse.json({ proxies: proxies || [], profile });
}

export async function POST(req: Request) {
  const body = await req.json();
  const displayName = String(body.displayName || "").trim();
  const username = String(body.username || "").trim();
  const profilePictureUrl = body.profilePictureUrl || null;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  if (!displayName || !username) {
    return NextResponse.json({ error: "Missing fields." });
  }

  const { data: existing } = await supabase
    .from("accounts")
    .select("id")
    .eq("owner_profile_id", user.id)
    .eq("type", "proxy");

  if ((existing?.length || 0) >= 4) {
    return NextResponse.json({ error: "Maximum 4 proxy accounts reached." });
  }

  const { error } = await supabase.from("accounts").insert({
    owner_profile_id: user.id,
    type: "proxy",
    username,
    display_name: displayName,
    profile_picture_url: profilePictureUrl,
    verification_status: "none"
  });

  if (error) return NextResponse.json({ error: "Failed to create proxy." });

  return NextResponse.json({ success: true });
}
