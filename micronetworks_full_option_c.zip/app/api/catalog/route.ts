import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const { data } = await supabase
    .from("items")
    .select("*")
    .order("created_at", { ascending: true });

  return NextResponse.json({ items: data || [] });
}
