import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const itemId = Number(body.itemId);

  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !itemId) return NextResponse.json({ error: "Not logged in." });

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, microbux_balance")
    .eq("id", user.id)
    .single();

  if (!profile) return NextResponse.json({ error: "Profile not found." });

  const { data: item } = await supabase
    .from("items")
    .select("*")
    .eq("id", itemId)
    .single();

  if (!item) return NextResponse.json({ error: "Item not found." });

  if (profile.microbux_balance < item.price_microbux) {
    return NextResponse.json({ error: "Not enough MicroBux." });
  }

  const { error: balErr } = await supabase
    .from("profiles")
    .update({
      microbux_balance: profile.microbux_balance - item.price_microbux
    })
    .eq("id", user.id);

  if (balErr) return NextResponse.json({ error: "Failed to update balance." });

  const { error: invErr } = await supabase
    .from("user_items")
    .insert({
      user_id: user.id,
      item_id: item.id
    });

  if (invErr) return NextResponse.json({ error: "Failed to add item." });

  await supabase.from("microbux_transactions").insert({
    user_id: user.id,
    amount: -item.price_microbux,
    reason: `Buy item ${item.name}`
  });

  return NextResponse.json({ success: true });
}
