import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

const DAILY_REWARD = 50;

export async function POST() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const now = new Date();

  const { data: row } = await supabase
    .from("daily_rewards")
    .select("*")
    .eq("user_id", user.id)
    .maybeSingle();

  if (row?.last_claimed_at) {
    const last = new Date(row.last_claimed_at);
    const diffMs = now.getTime() - last.getTime();
    if (diffMs < 24 * 60 * 60 * 1000) {
      return NextResponse.json({ error: "Already claimed today." });
    }
  }

  if (!row) {
    await supabase.from("daily_rewards").insert({
      user_id: user.id,
      last_claimed_at: now.toISOString(),
      streak: 1
    });
  } else {
    await supabase
      .from("daily_rewards")
      .update({
        last_claimed_at: now.toISOString(),
        streak: (row.streak || 0) + 1
      })
      .eq("user_id", user.id);
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("microbux_balance")
    .eq("id", user.id)
    .single();

  const current = profile?.microbux_balance || 0;

  await supabase
    .from("profiles")
    .update({ microbux_balance: current + DAILY_REWARD })
    .eq("id", user.id);

  await supabase.from("microbux_transactions").insert({
    user_id: user.id,
    amount: DAILY_REWARD,
    reason: "Daily reward"
  });

  return NextResponse.json({ success: true, amount: DAILY_REWARD });
}
