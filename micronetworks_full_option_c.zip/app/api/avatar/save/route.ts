import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const avatarConfig = body.avatarConfig;

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: mainAccount } = await supabase
    .from("accounts")
    .select("id")
    .eq("owner_profile_id", user.id)
    .eq("type", "main")
    .single();

  if (!mainAccount) {
    return NextResponse.json({ error: "Main account not found." });
  }

  const { error } = await supabase
    .from("accounts")
    .update({ avatar_config: avatarConfig })
    .eq("id", mainAccount.id);

  if (error) {
    return NextResponse.json({ error: "Failed to save avatar." });
  }

  return NextResponse.json({ success: true });
}
