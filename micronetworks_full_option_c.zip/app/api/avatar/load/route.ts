import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: active } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = active?.active_account_id;

  if (!activeId) {
    return NextResponse.json({ error: "No active account." });
  }

  const { data: account } = await supabase
    .from("accounts")
    .select("*")
    .eq("id", activeId)
    .single();

  const { data: items } = await supabase
    .from("user_items")
    .select("ownership_id, item:items(*)")
    .eq("user_id", user.id);

  return NextResponse.json({
    activeAccount: account,
    ownedItems: items || [],
    avatarConfig: account?.avatar_config || {}
  });
}
