import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const accountId = String(body.accountId || "");
  const type = String(body.type || "");

  if (!["government","business"].includes(type)) {
    return NextResponse.json({ error: "Invalid type." });
  }

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: acc } = await supabase
    .from("accounts")
    .select("id, owner_profile_id, type")
    .eq("id", accountId)
    .single();

  if (!acc || acc.owner_profile_id !== user.id) {
    return NextResponse.json({ error: "Not your account." });
  }

  if (acc.type !== "proxy") {
    return NextResponse.json({ error: "Only proxy accounts can apply." });
  }

  const { error } = await supabase.from("verification_requests").insert({
    account_id: acc.id,
    requested_type: type
  });

  if (error) return NextResponse.json({ error: "Failed to submit." });

  return NextResponse.json({ success: true });
}
