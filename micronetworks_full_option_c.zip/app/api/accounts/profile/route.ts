import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const username = searchParams.get("username");

  if (!username) return NextResponse.json({ account: null });

  const { data: account } = await supabase
    .from("accounts")
    .select("*")
    .eq("username", username)
    .maybeSingle();

  return NextResponse.json({ account: account || null });
}
