import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const accountId = String(body.accountId || "");

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: acc } = await supabase
    .from("accounts")
    .select("id, owner_profile_id")
    .eq("id", accountId)
    .single();

  if (!acc || acc.owner_profile_id !== user.id) {
    return NextResponse.json({ error: "Not your account." });
  }

  const { error } = await supabase.from("active_accounts").upsert(
    {
      owner_profile_id: user.id,
      active_account_id: accountId
    },
    { onConflict: "owner_profile_id" }
  );

  if (error) return NextResponse.json({ error: "Failed to switch." });

  return NextResponse.json({ success: true });
}
