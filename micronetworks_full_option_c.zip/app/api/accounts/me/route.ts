import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ accounts: [], activeAccountId: null });

  const { data: accounts } = await supabase
    .from("accounts")
    .select("*")
    .eq("owner_profile_id", user.id);

  const { data: active } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  return NextResponse.json({
    accounts: accounts || [],
    activeAccountId: active?.active_account_id || accounts?.[0]?.id || null
  });
}
