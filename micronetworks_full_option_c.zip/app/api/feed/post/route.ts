import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const content = String(body.content || "").trim();
  if (!content) return NextResponse.json({ error: "Empty content." });

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;
  if (!activeId) return NextResponse.json({ error: "No active account." });

  const { error } = await supabase.from("posts").insert({
    author_account_id: activeId,
    content
  });

  if (error) return NextResponse.json({ error: "Failed to post." });

  return NextResponse.json({ success: true });
}
