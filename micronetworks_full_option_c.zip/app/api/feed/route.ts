import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ posts: [] });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;

  const { data: followingRows } = await supabase
    .from("follows")
    .select("following_account_id")
    .eq("follower_account_id", activeId as string);

  const followingIds =
    (followingRows || []).map((f) => f.following_account_id) || [];

  const authorIds = [activeId, ...followingIds].filter(Boolean);

  if (!authorIds.length) return NextResponse.json({ posts: [] });

  const { data: posts } = await supabase
    .from("posts")
    .select("*, author_account:accounts(*)")
    .in("author_account_id", authorIds)
    .order("created_at", { ascending: false })
    .limit(50);

  return NextResponse.json({ posts: posts || [] });
}
