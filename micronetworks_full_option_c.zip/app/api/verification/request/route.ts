import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const accountId = String(body.accountId || "");
  const requestedType = String(body.requestedType || "");

  if (!["government", "business"].includes(requestedType)) {
    return NextResponse.json({ error: "Invalid requested type." });
  }

  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: acc } = await supabase
    .from("accounts")
    .select("id, owner_profile_id, type")
    .eq("id", accountId)
    .single();

  if (!acc || acc.owner_profile_id !== user.id) {
    return NextResponse.json({ error: "You do not own this account." });
  }
  if (acc.type !== "proxy") {
    return NextResponse.json({ error: "Only proxy accounts can request verification." });
  }

  const { error } = await supabase.from("verification_requests").insert({
    account_id: accountId,
    requested_type: requestedType
  });

  if (error) {
    return NextResponse.json({ error: "Failed to submit verification request." });
  }

  return NextResponse.json({ success: true });
}
