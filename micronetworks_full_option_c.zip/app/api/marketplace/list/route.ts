import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const ownershipId = Number(body.ownershipId);
  const price = Number(body.price);

  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !ownershipId || !price) {
    return NextResponse.json({ error: "Invalid data." });
  }

  const { data: inv } = await supabase
    .from("user_items")
    .select("*")
    .eq("ownership_id", ownershipId)
    .single();

  if (!inv || inv.user_id !== user.id) {
    return NextResponse.json({ error: "Not your item." });
  }

  const { error } = await supabase.from("market_listings").insert({
    ownership_id: ownershipId,
    seller_user_id: user.id,
    price_microbux: price
  });

  if (error) return NextResponse.json({ error: "Failed to create listing." });

  return NextResponse.json({ success: true });
}
