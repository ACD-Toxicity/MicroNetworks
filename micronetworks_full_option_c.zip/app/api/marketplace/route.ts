import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const { data } = await supabase
    .from("market_listings")
    .select("*, item:items(*)")
    .eq("active", true)
    .order("created_at", { ascending: false });

  return NextResponse.json({ listings: data || [] });
}
