import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const listingId = Number(body.listingId);

  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !listingId) return NextResponse.json({ error: "Not logged in." });

  const { data: listing } = await supabase
    .from("market_listings")
    .select("*, item:items(*), ownership:user_items(ownership_id, user_id, item_id)")
    .eq("id", listingId)
    .eq("active", true)
    .single();

  if (!listing) return NextResponse.json({ error: "Listing not found." });
  if (listing.seller_user_id === user.id) {
    return NextResponse.json({ error: "You cannot buy your own listing." });
  }

  const { data: buyerProfile } = await supabase
    .from("profiles")
    .select("id, microbux_balance")
    .eq("id", user.id)
    .single();

  if (!buyerProfile) return NextResponse.json({ error: "Profile not found." });

  if (buyerProfile.microbux_balance < listing.price_microbux) {
    return NextResponse.json({ error: "Not enough MicroBux." });
  }

  const { data: sellerProfile } = await supabase
    .from("profiles")
    .select("id, microbux_balance")
    .eq("id", listing.seller_user_id)
    .single();

  if (!sellerProfile) return NextResponse.json({ error: "Seller not found." });

  const { error: buyerErr } = await supabase
    .from("profiles")
    .update({
      microbux_balance: buyerProfile.microbux_balance - listing.price_microbux
    })
    .eq("id", buyerProfile.id);

  if (buyerErr) return NextResponse.json({ error: "Failed buyer balance." });

  const { error: sellerErr } = await supabase
    .from("profiles")
    .update({
      microbux_balance: sellerProfile.microbux_balance + listing.price_microbux
    })
    .eq("id", sellerProfile.id);

  if (sellerErr) return NextResponse.json({ error: "Failed seller balance." });

  const { error: transferErr } = await supabase
    .from("user_items")
    .update({ user_id: buyerProfile.id })
    .eq("ownership_id", listing.ownership_id);

  if (transferErr) return NextResponse.json({ error: "Failed to transfer item." });

  await supabase
    .from("market_listings")
    .update({ active: false })
    .eq("id", listing.id);

  await supabase.from("microbux_transactions").insert([
    {
      user_id: buyerProfile.id,
      amount: -listing.price_microbux,
      reason: `Marketplace buy ${listing.item.name}`
    },
    {
      user_id: sellerProfile.id,
      amount: listing.price_microbux,
      reason: `Marketplace sell ${listing.item.name}`
    }
  ]);

  return NextResponse.json({ success: true });
}
