import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const partnerId = searchParams.get("partnerId");

  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !partnerId) return NextResponse.json({ messages: [] });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;
  if (!activeId) return NextResponse.json({ messages: [] });

  const { data } = await supabase
    .from("messages")
    .select("*")
    .or(`sender_account_id.eq.${activeId},receiver_account_id.eq.${activeId}`)
    .or(`sender_account_id.eq.${partnerId},receiver_account_id.eq.${partnerId}`)
    .order("created_at", { ascending: true });

  const messages =
    data?.map((m) => ({
      id: m.id,
      content: m.content,
      isMine: m.sender_account_id === activeId
    })) || [];

  return NextResponse.json({ messages });
}
