import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const receiverAccountId = String(body.receiverAccountId || "");
  const content = String(body.content || "").trim();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  if (!receiverAccountId || !content) {
    return NextResponse.json({ error: "Missing fields." });
  }

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;
  if (!activeId) return NextResponse.json({ error: "No active account." });

  const { error } = await supabase.from("messages").insert({
    sender_account_id: activeId,
    receiver_account_id: receiverAccountId,
    content
  });

  if (error) return NextResponse.json({ error: "Failed to send." });

  return NextResponse.json({ success: true });
}
