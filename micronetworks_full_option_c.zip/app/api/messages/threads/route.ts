import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ threads: [] });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;
  if (!activeId) return NextResponse.json({ threads: [] });

  const { data } = await supabase
    .from("messages")
    .select("id, sender_account_id, receiver_account_id, content, created_at")
    .or(`sender_account_id.eq.${activeId},receiver_account_id.eq.${activeId}`)
    .order("created_at", { ascending: false });

  if (!data) return NextResponse.json({ threads: [] });

  const partners = new Map<string, { last_message: string; created_at: string }>();

  for (const m of data) {
    const partnerId =
      m.sender_account_id === activeId ? m.receiver_account_id : m.sender_account_id;
    if (!partners.has(partnerId)) {
      partners.set(partnerId, {
        last_message: m.content,
        created_at: m.created_at
      });
    }
  }

  const partnerIds = Array.from(partners.keys());
  if (!partnerIds.length) return NextResponse.json({ threads: [] });

  const { data: partnerAccounts } = await supabase
    .from("accounts")
    .select("id, username")
    .in("id", partnerIds);

  const threads = (partnerAccounts || []).map((acc) => ({
    partner: acc,
    last_message: partners.get(acc.id)?.last_message || ""
  }));

  return NextResponse.json({ threads });
}
