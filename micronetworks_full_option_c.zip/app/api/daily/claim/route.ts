import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

const REWARD_BASE = 50; -- 50 MicroBux per day

export async function POST() {
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (!profile) return NextResponse.json({ error: "Profile missing." });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const mainId = activeRow?.active_account_id;
  if (!mainId) {
    return NextResponse.json({ error: "No active account selected." });
  }

  const { data: rewardRow } = await supabase
    .from("daily_rewards")
    .select("*")
    .eq("profile_id", user.id)
    .maybeSingle();

  const now = new Date();
  let streak = rewardRow?.streak || 0;
  let canClaim = false;

  if (!rewardRow?.last_claimed_at) {
    canClaim = true;
    streak = 1;
  } else {
    const last = new Date(rewardRow.last_claimed_at);
    const diffDays = Math.floor(
      (now.getTime() - last.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (diffDays >= 1) {
      canClaim = true;
      streak = diffDays === 1 ? streak + 1 : 1;
    }
  }

  if (!canClaim) {
    return NextResponse.json({ error: "Already claimed for today." });
  }

  const reward = REWARD_BASE + (streak - 1) * 10;

  if (rewardRow) {
    await supabase
      .from("daily_rewards")
      .update({
        last_claimed_at: now.toISOString(),
        streak
      })
      .eq("id", rewardRow.id);
  } else {
    await supabase.from("daily_rewards").insert({
      profile_id: user.id,
      last_claimed_at: now.toISOString(),
      streak
    });
  }

  await supabase.rpc("increment_microbux", {
    p_account_id: mainId,
    p_amount: reward
  }).catch(() => {});

  return NextResponse.json({ success: true, streak, reward });
}
