import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ notifications: [] });

  const { data } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(20);

  const notifications =
    data?.map((n) => ({
      id: n.id,
      is_read: n.is_read,
      created_at: n.created_at,
      message: n.type || "Notification"
    })) || [];

  return NextResponse.json({ notifications });
}
