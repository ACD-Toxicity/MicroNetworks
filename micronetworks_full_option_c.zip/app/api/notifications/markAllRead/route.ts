import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST() {
  const {
    data: { user }
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not logged in." });

  await supabase
    .from("notifications")
    .update({ is_read: true })
    .eq("user_id", user.id)
    .eq("is_read", false);

  return NextResponse.json({ success: true });
}
