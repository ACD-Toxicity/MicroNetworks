import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function POST(req: Request) {
  const body = await req.json();
  const targetAccountId = String(body.targetAccountId || "");
  const action = String(body.action || "");

  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !targetAccountId) return NextResponse.json({ error: "Not logged in." });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;
  if (!activeId) return NextResponse.json({ error: "No active account." });
  if (activeId === targetAccountId) return NextResponse.json({ error: "Cannot follow yourself." });

  if (action === "follow") {
    const { error } = await supabase.from("follows").insert({
      follower_account_id: activeId,
      following_account_id: targetAccountId
    });
    if (error && !error.message.includes("duplicate")) {
      return NextResponse.json({ error: "Failed to follow." });
    }
  } else if (action === "unfollow") {
    await supabase
      .from("follows")
      .delete()
      .eq("follower_account_id", activeId)
      .eq("following_account_id", targetAccountId);
  } else {
    return NextResponse.json({ error: "Invalid action." });
  }

  return NextResponse.json({ success: true });
}
