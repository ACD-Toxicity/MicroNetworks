import { NextResponse } from "next/server";
import { supabase } from "@/lib/supabaseServer";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const accountId = searchParams.get("accountId");

  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !accountId) return NextResponse.json({ isFollowing: false });

  const { data: activeRow } = await supabase
    .from("active_accounts")
    .select("active_account_id")
    .eq("owner_profile_id", user.id)
    .single();

  const activeId = activeRow?.active_account_id;
  if (!activeId) return NextResponse.json({ isFollowing: false });

  const { data } = await supabase
    .from("follows")
    .select("id")
    .eq("follower_account_id", activeId)
    .eq("following_account_id", accountId)
    .maybeSingle();

  return NextResponse.json({ isFollowing: !!data });
}
