import type { ReactNode } from "react";

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <div style={{ maxWidth: 1120, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 12 }}>
        Admin Panel
      </h1>
      <p style={{ fontSize: 13, color: "#9ca3af", marginBottom: 16 }}>
        Internal tools for managing MicroNetworks (verification, users, items, economy).
      </p>
      {children}
    </div>
  );
}
