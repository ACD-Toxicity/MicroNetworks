"use client";

import { useEffect, useState, useTransition } from "react";

export default function VerificationReview() {
  const [requests, setRequests] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/admin/verification");
        const data = await res.json();
        setRequests(data.requests || []);
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, []);

  function act(id: number, approve: boolean) {
    startTransition(async () => {
      setMessage("");
      try {
        const res = await fetch("/api/admin/verification", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, approve })
        });
        const data = await res.json();
        if (data.error) setMessage(data.error);
        else {
          setMessage("Updated.");
          window.location.reload();
        }
      } catch (e) {
        console.error(e);
        setMessage("Failed to update.");
      }
    });
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {message && (
        <p style={{ fontSize: 12, color: "#4ade80" }}>{message}</p>
      )}
      {requests.map((req) => (
        <div
          key={req.id}
          style={{
            padding: 10,
            borderRadius: 12,
            border: "1px solid rgba(30,64,175,0.7)",
            background: "#020617",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 8
          }}
        >
          <div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>
              @{req.account.username} ({req.account.display_name})
            </div>
            <div style={{ fontSize: 12, color: "#9ca3af" }}>
              Requested: {req.requested_type} • Status: {req.status}
            </div>
          </div>
          {req.status === "pending" && (
            <div style={{ display: "flex", gap: 8 }}>
              <button
                onClick={() => act(req.id, true)}
                disabled={isPending}
                style={{
                  padding: "4px 10px",
                  borderRadius: 999,
                  border: "none",
                  background: "#16a34a",
                  color: "white",
                  fontSize: 11,
                  cursor: "pointer"
                }}
              >
                Approve
              </button>
              <button
                onClick={() => act(req.id, false)}
                disabled={isPending}
                style={{
                  padding: "4px 10px",
                  borderRadius: 999,
                  border: "none",
                  background: "#b91c1c",
                  color: "white",
                  fontSize: 11,
                  cursor: "pointer"
                }}
              >
                Deny
              </button>
            </div>
          )}
        </div>
      ))}
      {requests.length === 0 && (
        <p style={{ fontSize: 13, color: "#9ca3af" }}>
          No verification requests.
        </p>
      )}
    </div>
  );
}
