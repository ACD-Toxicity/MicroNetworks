"use client";

import { useEffect, useState } from "react";

export default function VerificationAdminPage() {
  const [requests, setRequests] = useState<any[]>([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/admin/verification");
      const data = await res.json();
      setRequests(data.requests || []);
    }
    load();
  }, []);

  async function decide(id: number, decision: "approved" | "denied") {
    setMessage("");
    const res = await fetch("/api/admin/verification/decide", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, decision })
    });
    const data = await res.json();
    if (data.error) setMessage(data.error);
    else {
      setMessage("Updated.");
      const res2 = await fetch("/api/admin/verification");
      const data2 = await res2.json();
      setRequests(data2.requests || []);
    }
  }

  return (
    <div
      style={{
        borderRadius: 16,
        border: "1px solid rgba(30,64,175,0.7)",
        background: "#020617",
        padding: 12
      }}
    >
      <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 6 }}>
        Verification Requests
      </h2>
      {message && (
        <p style={{ fontSize: 12, color: "#4ade80", marginBottom: 6 }}>
          {message}
        </p>
      )}
      {requests.length === 0 ? (
        <p style={{ fontSize: 13, color: "#9ca3af" }}>
          No pending requests.
        </p>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {requests.map((r) => (
            <div
              key={r.id}
              style={{
                borderRadius: 10,
                border: "1px solid rgba(15,23,42,0.9)",
                padding: 8
              }}
            >
              <div style={{ fontSize: 13, fontWeight: 600 }}>
                @{r.account.username} – {r.requested_type}
              </div>
              <div style={{ fontSize: 11, color: "#9ca3af" }}>
                Submitted: {new Date(r.submitted_at).toLocaleString()}
              </div>
              <div style={{ marginTop: 6, display: "flex", gap: 8 }}>
                <button
                  onClick={() => decide(r.id, "approved")}
                  style={{
                    padding: "4px 10px",
                    borderRadius: 999,
                    border: "none",
                    background: "#16a34a",
                    color: "white",
                    fontSize: 11,
                    cursor: "pointer"
                  }}
                >
                  Approve
                </button>
                <button
                  onClick={() => decide(r.id, "denied")}
                  style={{
                    padding: "4px 10px",
                    borderRadius: 999,
                    border: "none",
                    background: "#b91c1c",
                    color: "white",
                    fontSize: 11,
                    cursor: "pointer"
                  }}
                >
                  Deny
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
