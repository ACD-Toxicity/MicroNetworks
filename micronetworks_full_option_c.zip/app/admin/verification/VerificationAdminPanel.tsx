"use client";

import { useEffect, useState, useTransition } from "react";

export default function VerificationAdminPanel() {
  const [requests, setRequests] = useState<any[]>([]);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/admin/verification");
      const data = await res.json();
      setRequests(data.requests || []);
    }
    load();
  }, []);

  function review(id: number, approve: boolean) {
    startTransition(async () => {
      await fetch("/api/admin/verification/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, approve })
      });
      window.location.reload();
    });
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {requests.map((r) => (
        <div
          key={r.id}
          style={{
            padding: 10,
            borderRadius: 12,
            border: "1px solid rgba(30,64,175,0.7)",
            background: "#020617",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center"
          }}
        >
          <div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>
              @{r.account.username}
            </div>
            <div style={{ fontSize: 12, color: "#9ca3af" }}>
              Requested: {r.requested_type} · Status: {r.status}
            </div>
          </div>
          {r.status === "pending" && (
            <div style={{ display: "flex", gap: 6 }}>
              <button
                onClick={() => review(r.id, true)}
                disabled={isPending}
                style={{
                  padding: "4px 8px",
                  borderRadius: 999,
                  border: "none",
                  background: "#16a34a",
                  color: "white",
                  fontSize: 11,
                  cursor: "pointer"
                }}
              >
                Approve
              </button>
              <button
                onClick={() => review(r.id, false)}
                disabled={isPending}
                style={{
                  padding: "4px 8px",
                  borderRadius: 999,
                  border: "none",
                  background: "#b91c1c",
                  color: "white",
                  fontSize: 11,
                  cursor: "pointer"
                }}
              >
                Deny
              </button>
            </div>
          )}
        </div>
      ))}
      {!requests.length && (
        <p style={{ fontSize: 13, color: "#9ca3af" }}>No requests.</p>
      )}
    </div>
  );
}
