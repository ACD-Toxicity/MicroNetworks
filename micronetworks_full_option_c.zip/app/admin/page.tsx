export default function AdminHome() {
  return (
    <div style={{ display: "grid", gap: 16 }}>
      <section
        style={{
          borderRadius: 16,
          border: "1px solid rgba(30,64,175,0.7)",
          background: "#020617",
          padding: 12
        }}
      >
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 4 }}>
          Overview
        </h2>
        <p style={{ fontSize: 13, color: "#9ca3af" }}>
          Use the navigation to access verification requests, users, items, and economy tools.
        </p>
      </section>
    </div>
  );
}
