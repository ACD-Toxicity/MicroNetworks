"use client";

import { useEffect, useState, useTransition } from "react";

export default function AdminItemsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [slot, setSlot] = useState("shirt");
  const [rarity, setRarity] = useState("R");
  const [price, setPrice] = useState(100);
  const [imageUrl, setImageUrl] = useState("");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/catalog");
      const data = await res.json();
      setItems(data.items || []);
    }
    load();
  }, []);

  function createItem() {
    if (!name.trim() || !imageUrl.trim()) {
      setMessage("Name and image URL required.");
      return;
    }
    startTransition(async () => {
      setMessage("");
      const res = await fetch("/api/admin/items/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          slot,
          rarity,
          price_microbux: price,
          image_url: imageUrl
        })
      });
      const data = await res.json();
      if (data.error) setMessage(data.error);
      else {
        setMessage("Item created.");
        setName("");
        setImageUrl("");
        const res2 = await fetch("/api/catalog");
        const data2 = await res2.json();
        setItems(data2.items || []);
      }
    });
  }

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <section
        style={{
          borderRadius: 16,
          border: "1px solid rgba(30,64,175,0.7)",
          background: "#020617",
          padding: 12
        }}
      >
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 6 }}>
          Create Item
        </h2>
        {message && (
          <p style={{ fontSize: 12, color: "#4ade80" }}>{message}</p>
        )}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit,minmax(140px,1fr))",
            gap: 8,
            marginTop: 8
          }}
        >
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.9)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          />
          <input
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="Image URL"
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.9)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          />
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(Number(e.target.value))}
            placeholder="Price"
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.9)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          />
          <select
            value={slot}
            onChange={(e) => setSlot(e.target.value)}
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.9)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          >
            <option value="base">Base</option>
            <option value="hair_front">Hair Front</option>
            <option value="hair_back">Hair Back</option>
            <option value="eyes">Eyes</option>
            <option value="mouth">Mouth</option>
            <option value="shirt">Shirt</option>
            <option value="pants">Pants</option>
            <option value="accessory1">Accessory 1</option>
            <option value="accessory2">Accessory 2</option>
            <option value="back">Back</option>
            <option value="effect">Effect</option>
          </select>
          <select
            value={rarity}
            onChange={(e) => setRarity(e.target.value)}
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.9)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          >
            <option value="R">Rare</option>
            <option value="UR">Ultra Rare</option>
            <option value="LR">Limited Rare</option>
          </select>
        </div>
        <button
          onClick={createItem}
          disabled={isPending}
          style={{
            marginTop: 10,
            padding: "6px 14px",
            borderRadius: 999,
            border: "none",
            background: "#2563eb",
            color: "white",
            fontSize: 13,
            cursor: "pointer"
          }}
        >
          {isPending ? "Creating..." : "Create Item"}
        </button>
      </section>

      <section
        style={{
          borderRadius: 16,
          border: "1px solid rgba(30,64,175,0.7)",
          background: "#020617",
          padding: 12
        }}
      >
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 6 }}>
          Items
        </h2>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))",
            gap: 10
          }}
        >
          {items.map((i) => (
            <div
              key={i.id}
              style={{
                borderRadius: 12,
                border: "1px solid rgba(15,23,42,0.9)",
                padding: 6
              }}
            >
              <div style={{ fontSize: 13, fontWeight: 600 }}>{i.name}</div>
              <div style={{ fontSize: 11, color: "#9ca3af" }}>
                {i.slot} • {i.rarity} • {i.price_microbux} MBX
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
