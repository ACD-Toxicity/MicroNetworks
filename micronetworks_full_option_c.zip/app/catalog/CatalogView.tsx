"use client";

import { useEffect, useState, useTransition } from "react";

export default function CatalogView() {
  const [items, setItems] = useState<any[]>([]);
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/catalog");
      const data = await res.json();
      setItems(data.items || []);
    }
    load();
  }, []);

  function rarityLabel(r: string) {
    if (r === "R") return "Rare";
    if (r === "UR") return "Ultra Rare";
    if (r === "LR") return "Limited Rare";
    return r;
  }

  function buy(itemId: number) {
    startTransition(async () => {
      setMessage("");
      const res = await fetch("/api/catalog/buy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId })
      });
      const data = await res.json();
      if (data.error) setMessage(data.error);
      else setMessage("Purchased!");
    });
  }

  return (
    <div>
      {message && (
        <p style={{ fontSize: 12, color: "#4ade80", marginBottom: 8 }}>
          {message}
        </p>
      )}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))",
          gap: 12
        }}
      >
        {items.map((item) => (
          <div
            key={item.id}
            style={{
              borderRadius: 14,
              border: "1px solid rgba(30,64,175,0.7)",
              background: "#020617",
              padding: 8,
              display: "flex",
              flexDirection: "column",
              gap: 4
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={item.image_url}
              alt={item.name}
              style={{
                width: "100%",
                borderRadius: 10,
                marginBottom: 4
              }}
            />
            <div style={{ fontSize: 13, fontWeight: 600 }}>{item.name}</div>
            <div style={{ fontSize: 11, color: "#9ca3af" }}>
              {rarityLabel(item.rarity)} • Slot: {item.slot}
            </div>
            <div style={{ fontSize: 12, color: "#7dd3fc" }}>
              {item.price_microbux} MBX
            </div>
            <button
              onClick={() => buy(item.id)}
              disabled={isPending}
              style={{
                marginTop: 4,
                padding: "4px 10px",
                borderRadius: 999,
                border: "none",
                background: "#16a34a",
                color: "white",
                fontSize: 12,
                cursor: "pointer"
              }}
            >
              {isPending ? "Buying..." : "Buy"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
