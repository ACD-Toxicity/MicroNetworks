import CatalogView from "./CatalogView";

export default function CatalogPage() {
  return (
    <div style={{ maxWidth: 1040, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>
        Catalog
      </h1>
      <p style={{ fontSize: 14, color: "#9ca3af", marginBottom: 16 }}>
        Buy avatar items with MicroBux (MBX).
      </p>
      <CatalogView />
    </div>
  );
}
