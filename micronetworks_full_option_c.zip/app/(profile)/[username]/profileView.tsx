"use client";

import { useEffect, useState } from "react";
import { AvatarRenderer } from "@/components/avatar/AvatarRenderer";
import { VerificationBadge } from "@/components/VerificationBadge";
import Link from "next/link";

export default function ProfileView({ username }: { username: string }) {
  const [account, setAccount] = useState<any | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);

  useEffect(() => {
    async function load() {
      const res = await fetch(`/api/accounts/profile?username=${username}`);
      const data = await res.json();
      setAccount(data.account || null);

      const res2 = await fetch("/api/accounts/me");
      const data2 = await res2.json();
      setActiveId(data2.activeAccountId || null);
      setLoading(false);

      if (data.account && data2.activeAccountId && data.account.id !== data2.activeAccountId) {
        const res3 = await fetch(`/api/follow/status?accountId=${data.account.id}`);
        const data3 = await res3.json();
        setIsFollowing(data3.isFollowing);
      }
    }
    load();
  }, [username]);

  if (loading) return <p style={{ fontSize: 14 }}>Loading...</p>;
  if (!account) return <p style={{ fontSize: 14, color: "#f97373" }}>Account not found.</p>;

  const isSelf = account.id === activeId;

  async function toggleFollow() {
    if (!account) return;
    const action = isFollowing ? "unfollow" : "follow";
    await fetch("/api/follow/toggle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetAccountId: account.id, action })
    });
    setIsFollowing(!isFollowing);
  }

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <section style={{ display: "flex", gap: 16 }}>
        <AvatarRenderer account={account} size={120} />
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}>
            {account.display_name}
            <VerificationBadge status={account.verification_status} size={16} />
          </h1>
          <div style={{ fontSize: 14, color: "#9ca3af" }}>@{account.username}</div>
          {account.bio && (
            <p style={{ marginTop: 8, fontSize: 14, whiteSpace: "pre-wrap" }}>
              {account.bio}
            </p>
          )}
        </div>
      </section>

      <section style={{ display: "flex", gap: 8 }}>
        {isSelf ? (
          <>
            {account.type === "main" && (
              <Link
                href="/avatar"
                style={{
                  padding: "6px 12px",
                  borderRadius: 999,
                  background: "#2563eb",
                  color: "white",
                  fontSize: 13
                }}
              >
                Edit Avatar
              </Link>
            )}
            <Link
              href={`/account/edit/${account.username}`}
              style={{
                padding: "6px 12px",
                borderRadius: 999,
                background: "#374151",
                color: "white",
                fontSize: 13
              }}
            >
              Edit Profile
            </Link>
          </>
        ) : (
          <>
            <button
              onClick={toggleFollow}
              style={{
                padding: "6px 12px",
                borderRadius: 999,
                background: isFollowing ? "#374151" : "#2563eb",
                color: "white",
                fontSize: 13,
                border: "none",
                cursor: "pointer"
              }}
            >
              {isFollowing ? "Unfollow" : "Follow"}
            </button>
            <Link
              href="/messages"
              style={{
                padding: "6px 12px",
                borderRadius: 999,
                background: "#374151",
                color: "white",
                fontSize: 13
              }}
            >
              Message
            </Link>
          </>
        )}
      </section>

      <section>
        <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>
          Posts
        </h2>
        <p style={{ fontSize: 13, color: "#9ca3af" }}>
          User posts feed can be rendered here.
        </p>
      </section>
    </div>
  );
}
