import ProfileView from "./profileView";

export default function ProfilePage({ params }: { params: { username: string } }) {
  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "24px 16px" }}>
      <ProfileView username={params.username} />
    </div>
  );
}
