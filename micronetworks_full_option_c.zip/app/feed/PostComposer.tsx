"use client";

import { useState, useTransition } from "react";

export default function PostComposer() {
  const [content, setContent] = useState("");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  function submit() {
    if (!content.trim()) return;
    startTransition(async () => {
      setMessage("");
      try {
        const res = await fetch("/api/feed/post", {
          method: "POST",
          body: JSON.stringify({ content: content.trim() }),
          headers: { "Content-Type": "application/json" }
        });
        const data = await res.json();
        if (data.error) setMessage(data.error);
        else {
          setMessage("Posted!");
          setContent("");
          window.location.reload();
        }
      } catch (e) {
        console.error(e);
        setMessage("Failed to post.");
      }
    });
  }

  return (
    <div
      style={{
        borderRadius: 16,
        border: "1px solid rgba(30,64,175,0.7)",
        background: "#020617",
        padding: 12
      }}
    >
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        rows={3}
        placeholder="What's happening?"
        style={{
          width: "100%",
          borderRadius: 12,
          border: "1px solid rgba(15,23,42,0.8)",
          background: "#020617",
          color: "#e5e7eb",
          padding: 8,
          fontSize: 14,
          resize: "none"
        }}
      />
      <div
        style={{
          marginTop: 8,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          fontSize: 12
        }}
      >
        {message && <span style={{ color: "#4ade80" }}>{message}</span>}
        <button
          onClick={submit}
          disabled={isPending}
          style={{
            padding: "6px 14px",
            borderRadius: 999,
            border: "none",
            background: "#2563eb",
            color: "white",
            cursor: "pointer",
            fontSize: 13
          }}
        >
          {isPending ? "Posting..." : "Post"}
        </button>
      </div>
    </div>
  );
}
