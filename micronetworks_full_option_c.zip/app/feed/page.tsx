import Feed from "./Feed";
import PostComposer from "./PostComposer";

export default function FeedPage() {
  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "24px 16px" }}>
      <PostComposer />
      <div style={{ height: 16 }} />
      <Feed />
    </div>
  );
}
