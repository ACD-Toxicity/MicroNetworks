"use client";

import { useEffect, useState } from "react";
import { AvatarRenderer } from "@/components/avatar/AvatarRenderer";
import { VerificationBadge } from "@/components/VerificationBadge";

export default function Feed() {
  const [posts, setPosts] = useState<any[]>([]);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/feed");
        const data = await res.json();
        setPosts(data.posts || []);
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, []);

  if (!posts.length) {
    return (
      <p style={{ fontSize: 14, color: "#9ca3af" }}>
        No posts yet. Be the first to post!
      </p>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {posts.map((p) => (
        <div
          key={p.id}
          style={{
            display: "flex",
            gap: 10,
            padding: 10,
            borderRadius: 16,
            border: "1px solid rgba(30,64,175,0.7)",
            background: "#020617"
          }}
        >
          <AvatarRenderer account={p.author_account} size={40} />
          <div style={{ flex: 1 }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 13,
                marginBottom: 2
              }}
            >
              <span style={{ fontWeight: 600 }}>
                {p.author_account.display_name}
              </span>
              <VerificationBadge
                status={p.author_account.verification_status}
              />
              <span style={{ fontSize: 12, color: "#9ca3af" }}>
                @{p.author_account.username}
              </span>
            </div>
            <p
              style={{
                fontSize: 14,
                color: "#e5e7eb",
                whiteSpace: "pre-wrap",
                marginBottom: 4
              }}
            >
              {p.content}
            </p>
            <div style={{ fontSize: 11, color: "#6b7280" }}>
              {new Date(p.created_at).toLocaleString()}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
