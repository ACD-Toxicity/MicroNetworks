import AvatarBuilder from "./AvatarBuilder";

export default function AvatarPage() {
  return (
    <div style={{ maxWidth: 1120, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>
        Avatar Builder
      </h1>
      <p style={{ fontSize: 14, color: "#9ca3af", marginBottom: 16 }}>
        Customize your paperdoll avatar for your main account.
      </p>
      <AvatarBuilder />
    </div>
  );
}
