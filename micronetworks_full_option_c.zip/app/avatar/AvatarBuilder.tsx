"use client";

import { useEffect, useState, useTransition } from "react";
import { AvatarRenderer } from "@/components/avatar/AvatarRenderer";

const SLOTS = [
  "base",
  "eyes",
  "mouth",
  "hair_back",
  "hair_front",
  "shirt",
  "pants",
  "accessory1",
  "accessory2",
  "back",
  "effect"
];

export default function AvatarBuilder() {
  const [activeAccount, setActiveAccount] = useState<any | null>(null);
  const [ownedItems, setOwnedItems] = useState<any[]>([]);
  const [avatarConfig, setAvatarConfig] = useState<any>({});
  const [activeSlot, setActiveSlot] = useState<string>("hair_front");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/avatar/load");
        const data = await res.json();
        if (data.error) {
          setMessage(data.error);
          return;
        }
        setActiveAccount(data.activeAccount);
        setOwnedItems(data.ownedItems || []);
        setAvatarConfig(data.avatarConfig || {});
      } catch (e) {
        console.error(e);
        setMessage("Failed to load avatar.");
      }
    }
    load();
  }, []);

  if (!activeAccount)
    return <p style={{ fontSize: 14 }}>Loading avatar builder...</p>;

  if (activeAccount.type !== "main") {
    return (
      <p style={{ fontSize: 14, color: "#f97373" }}>
        Switch to your main account to edit the avatar.
      </p>
    );
  }

  function equip(item: any) {
    setAvatarConfig((prev: any) => ({
      ...prev,
      [activeSlot]: item.item.image_url
    }));
  }

  function unequip() {
    setAvatarConfig((prev: any) => ({
      ...prev,
      [activeSlot]: null
    }));
  }

  function save() {
    startTransition(async () => {
      setMessage("");
      try {
        const res = await fetch("/api/avatar/save", {
          method: "POST",
          body: JSON.stringify({ avatarConfig }),
          headers: { "Content-Type": "application/json" }
        });
        const data = await res.json();
        if (data.error) setMessage(data.error);
        else setMessage("Avatar saved!");
      } catch (e) {
        console.error(e);
        setMessage("Failed to save.");
      }
    });
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "minmax(0,1.2fr) minmax(0,1.8fr)",
        gap: 24,
        alignItems: "flex-start"
      }}
    >
      <div>
        <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 8 }}>
          Preview
        </h2>
        <AvatarRenderer account={{ type: "main", avatar_config: avatarConfig }} size={220} />
        <button
          onClick={save}
          disabled={isPending}
          style={{
            marginTop: 12,
            padding: "8px 16px",
            borderRadius: 999,
            border: "none",
            background: "#2563eb",
            color: "white",
            fontSize: 14,
            cursor: "pointer"
          }}
        >
          {isPending ? "Saving..." : "Save Avatar"}
        </button>
        {message && (
          <p style={{ marginTop: 8, fontSize: 12, color: "#4ade80" }}>
            {message}
          </p>
        )}
      </div>
      <div>
        <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 8 }}>
          Edit Slot
        </h2>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
          {SLOTS.map((slot) => (
            <button
              key={slot}
              onClick={() => setActiveSlot(slot)}
              style={{
                padding: "4px 10px",
                borderRadius: 999,
                border:
                  activeSlot === slot
                    ? "1px solid #3b82f6"
                    : "1px solid rgba(30,64,175,0.7)",
                background:
                  activeSlot === slot ? "rgba(30,64,175,0.5)" : "transparent",
                fontSize: 11,
                cursor: "pointer"
              }}
            >
              {slot}
            </button>
          ))}
        </div>
        <button
          onClick={unequip}
          style={{
            marginBottom: 12,
            padding: "4px 10px",
            borderRadius: 999,
            border: "none",
            background: "#b91c1c",
            color: "white",
            fontSize: 12,
            cursor: "pointer"
          }}
        >
          Unequip
        </button>
        <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>
          Items for: <span style={{ textTransform: "capitalize" }}>{activeSlot}</span>
        </h3>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(90px,1fr))",
            gap: 8,
            maxHeight: 360,
            overflowY: "auto"
          }}
        >
          {ownedItems
            .filter((it: any) => it.item.slot === activeSlot)
            .map((it: any) => (
              <button
                key={it.ownership_id}
                onClick={() => equip(it)}
                style={{
                  borderRadius: 12,
                  border: "1px solid rgba(30,64,175,0.7)",
                  background: "#020617",
                  padding: 6,
                  cursor: "pointer"
                }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={it.item.image_url}
                  alt={it.item.name}
                  style={{
                    width: "100%",
                    borderRadius: 8,
                    marginBottom: 4
                  }}
                />
                <div
                  style={{
                    fontSize: 11,
                    textAlign: "center",
                    color: "#e5e7eb"
                  }}
                >
                  {it.item.name}
                </div>
              </button>
            ))}
        </div>
      </div>
    </div>
  );
}
