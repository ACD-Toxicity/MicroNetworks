"use client";

import { useEffect, useState, useTransition } from "react";

export default function MarketplaceView() {
  const [listings, setListings] = useState<any[]>([]);
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/marketplace");
      const data = await res.json();
      setListings(data.listings || []);
    }
    load();
  }, []);

  function buy(listingId: number) {
    startTransition(async () => {
      setMessage("");
      const res = await fetch("/api/marketplace/buy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ listingId })
      });
      const data = await res.json();
      if (data.error) setMessage(data.error);
      else {
        setMessage("Purchase successful.");
        const res2 = await fetch("/api/marketplace");
        const data2 = await res2.json();
        setListings(data2.listings || []);
      }
    });
  }

  return (
    <div>
      {message && (
        <p style={{ fontSize: 12, color: "#4ade80", marginBottom: 8 }}>
          {message}
        </p>
      )}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))",
          gap: 12
        }}
      >
        {listings.map((l) => (
          <div
            key={l.id}
            style={{
              borderRadius: 14,
              border: "1px solid rgba(30,64,175,0.7)",
              background: "#020617",
              padding: 8
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={l.item.image_url}
              alt={l.item.name}
              style={{
                width: "100%",
                borderRadius: 10,
                marginBottom: 4
              }}
            />
            <div style={{ fontSize: 13, fontWeight: 600 }}>{l.item.name}</div>
            <div style={{ fontSize: 11, color: "#9ca3af" }}>
              {l.item.rarity} • Slot: {l.item.slot}
            </div>
            <div style={{ fontSize: 12, color: "#7dd3fc" }}>
              Price: {l.price_microbux} MBX
            </div>
            <button
              onClick={() => buy(l.id)}
              disabled={isPending}
              style={{
                marginTop: 4,
                padding: "4px 10px",
                borderRadius: 999,
                border: "none",
                background: "#16a34a",
                color: "white",
                fontSize: 12,
                cursor: "pointer"
              }}
            >
              {isPending ? "Buying..." : "Buy"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
