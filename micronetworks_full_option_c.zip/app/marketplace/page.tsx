import MarketplaceView from "./MarketplaceView";

export default function MarketplacePage() {
  return (
    <div style={{ maxWidth: 1040, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>
        Marketplace
      </h1>
      <p style={{ fontSize: 14, color: "#9ca3af", marginBottom: 16 }}>
        Buy and sell Rare, Ultra Rare, and Limited Rare items from other users.
      </p>
      <MarketplaceView />
    </div>
  );
}
