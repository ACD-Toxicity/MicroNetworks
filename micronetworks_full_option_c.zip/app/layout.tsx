import "./globals.css";
import type { ReactNode } from "react";
import Link from "next/link";
import NotificationsBell from "@/components/NotificationsBell";
import AccountSwitcher from "@/components/AccountSwitcher";

export const metadata = {
  title: "MicroNetworks",
  description: "Social Avatar Network for Micronationalists"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header
          style={{
            borderBottom: "1px solid rgba(30,64,175,0.7)",
            background: "rgba(5,8,22,0.9)",
            backdropFilter: "blur(10px)"
          }}
        >
          <div
            style={{
              maxWidth: 1120,
              margin: "0 auto",
              padding: "8px 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 16
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Link href="/feed" style={{ fontWeight: 700, fontSize: 18 }}>
                MicroNetworks
              </Link>
              <nav
                style={{
                  display: "flex",
                  gap: 12,
                  fontSize: 13,
                  color: "#9ca3af"
                }}
              >
                <Link href="/feed">Feed</Link>
                <Link href="/messages">Messages</Link>
                <Link href="/account/proxies">Proxies</Link>
                <Link href="/avatar">Avatar</Link>
              </nav>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <NotificationsBell />
              <AccountSwitcher />
            </div>
          </div>
        </header>
        <main>
          {children}
        </main>
      </body>
    </html>
  );
}
