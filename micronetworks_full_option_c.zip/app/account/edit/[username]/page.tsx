import EditProfile from "./EditProfile";

export default function EditProfilePageWrapper({ params }: { params: { username: string } }) {
  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "24px 16px" }}>
      <EditProfile username={params.username} />
    </div>
  );
}
