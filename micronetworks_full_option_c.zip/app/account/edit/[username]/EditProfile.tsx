"use client";

import { useEffect, useState, useTransition } from "react";

export default function EditProfile({ username }: { username: string }) {
  const [account, setAccount] = useState<any | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [pfp, setPfp] = useState("");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      const res = await fetch(`/api/accounts/profile?username=${username}`);
      const data = await res.json();
      if (data.account) {
        setAccount(data.account);
        setDisplayName(data.account.display_name || "");
        setBio(data.account.bio || "");
        setPfp(data.account.profile_picture_url || "");
      }
    }
    load();
  }, [username]);

  function save() {
    if (!account) return;
    startTransition(async () => {
      setMessage("");
      const res = await fetch("/api/account/edit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accountId: account.id,
          displayName,
          bio,
          profilePictureUrl: pfp
        })
      });
      const data = await res.json();
      if (data.error) setMessage(data.error);
      else setMessage("Profile updated.");
    });
  }

  if (!account) {
    return <p style={{ fontSize: 14 }}>Loading...</p>;
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      <h1 style={{ fontSize: 20, fontWeight: 700 }}>
        Edit Profile (@{account.username})
      </h1>
      <input
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
        placeholder="Display Name"
        style={{
          padding: 8,
          borderRadius: 8,
          border: "1px solid rgba(15,23,42,0.8)",
          background: "#020617",
          color: "#e5e7eb",
          fontSize: 13
        }}
      />
      <textarea
        value={bio}
        onChange={(e) => setBio(e.target.value)}
        placeholder="Bio"
        rows={4}
        style={{
          padding: 8,
          borderRadius: 8,
          border: "1px solid rgba(15,23,42,0.8)",
          background: "#020617",
          color: "#e5e7eb",
          fontSize: 13,
          resize: "vertical"
        }}
      />
      {account.type === "proxy" && (
        <input
          value={pfp}
          onChange={(e) => setPfp(e.target.value)}
          placeholder="Profile Picture URL"
          style={{
            padding: 8,
            borderRadius: 8,
            border: "1px solid rgba(15,23,42,0.8)",
            background: "#020617",
            color: "#e5e7eb",
            fontSize: 13
          }}
        />
      )}
      <button
        onClick={save}
        disabled={isPending}
        style={{
          padding: "6px 14px",
          borderRadius: 999,
          border: "none",
          background: "#2563eb",
          color: "white",
          fontSize: 13,
          cursor: "pointer"
        }}
      >
        {isPending ? "Saving..." : "Save"}
      </button>
      {message && (
        <p style={{ fontSize: 12, color: "#4ade80" }}>{message}</p>
      )}
    </div>
  );
}
