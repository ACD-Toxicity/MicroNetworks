import ProxyManager from "./ProxyManager";

export default function ProxiesPage() {
  return (
    <div style={{ maxWidth: 960, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>
        Proxy Accounts
      </h1>
      <p style={{ fontSize: 14, color: "#9ca3af", marginBottom: 16 }}>
        Create and manage proxy identities for your micronations, businesses, or organizations.
      </p>
      <ProxyManager />
    </div>
  );
}
