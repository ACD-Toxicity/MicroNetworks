"use client";

import { useEffect, useState, useTransition } from "react";

export default function ProxyManager() {
  const [proxies, setProxies] = useState<any[]>([]);
  const [profile, setProfile] = useState<any | null>(null);
  const [newName, setNewName] = useState("");
  const [newUsername, setNewUsername] = useState("");
  const [newPfp, setNewPfp] = useState("");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    async function load() {
      const res = await fetch("/api/account/proxies");
      const data = await res.json();
      setProxies(data.proxies || []);
      setProfile(data.profile || null);
    }
    load();
  }, []);

  function createProxy() {
    if (!newName.trim() || !newUsername.trim()) {
      setMessage("Name and username are required.");
      return;
    }
    startTransition(async () => {
      setMessage("");
      const res = await fetch("/api/account/proxies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          displayName: newName.trim(),
          username: newUsername.trim(),
          profilePictureUrl: newPfp.trim() || null
        })
      });
      const data = await res.json();
      if (data.error) setMessage(data.error);
      else {
        setMessage("Proxy created.");
        setNewName("");
        setNewUsername("");
        setNewPfp("");
        const res2 = await fetch("/api/account/proxies");
        const data2 = await res2.json();
        setProxies(data2.proxies || []);
      }
    });
  }

  async function applyVerification(id: string, type: "government" | "business") {
    setMessage("");
    const res = await fetch("/api/account/verification/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId: id, type })
    });
    const data = await res.json();
    if (data.error) setMessage(data.error);
    else setMessage("Verification request submitted.");
  }

  return (
    <div style={{ display: "grid", gap: 24 }}>
      <section>
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>
          Your Proxy Accounts
        </h2>
        {proxies.length === 0 && (
          <p style={{ fontSize: 13, color: "#9ca3af" }}>
            You don't have any proxy accounts yet.
          </p>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {proxies.map((p) => (
            <div
              key={p.id}
              style={{
                borderRadius: 12,
                border: "1px solid rgba(30,64,175,0.7)",
                background: "#020617",
                padding: 10,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 16
              }}
            >
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>
                  {p.display_name} <span style={{ color: "#9ca3af" }}>@{p.username}</span>
                </div>
                <div style={{ fontSize: 12, color: "#9ca3af" }}>
                  Verification: {p.verification_status}
                </div>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  onClick={() => applyVerification(p.id, "government")}
                  style={{
                    padding: "4px 10px",
                    borderRadius: 999,
                    border: "none",
                    background: "#4b5563",
                    color: "white",
                    fontSize: 11,
                    cursor: "pointer"
                  }}
                >
                  Apply Gov
                </button>
                <button
                  onClick={() => applyVerification(p.id, "business")}
                  style={{
                    padding: "4px 10px",
                    borderRadius: 999,
                    border: "none",
                    background: "#ca8a04",
                    color: "white",
                    fontSize: 11,
                    cursor: "pointer"
                  }}
                >
                  Apply Business
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>
          Create New Proxy
        </h2>
        <p style={{ fontSize: 12, color: "#9ca3af", marginBottom: 8 }}>
          You can have up to 4 proxy accounts.
        </p>
        <div
          style={{
            display: "grid",
            gap: 8,
            maxWidth: 400
          }}
        >
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Display Name"
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.8)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          />
          <input
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            placeholder="Username"
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.8)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          />
          <input
            value={newPfp}
            onChange={(e) => setNewPfp(e.target.value)}
            placeholder="Profile Picture URL (optional)"
            style={{
              padding: 8,
              borderRadius: 8,
              border: "1px solid rgba(15,23,42,0.8)",
              background: "#020617",
              color: "#e5e7eb",
              fontSize: 13
            }}
          />
        </div>
        <button
          onClick={createProxy}
          disabled={isPending}
          style={{
            marginTop: 10,
            padding: "6px 14px",
            borderRadius: 999,
            border: "none",
            background: "#2563eb",
            color: "white",
            fontSize: 13,
            cursor: "pointer"
          }}
        >
          {isPending ? "Creating..." : "Create Proxy"}
        </button>
        {message && (
          <p style={{ marginTop: 8, fontSize: 12, color: "#4ade80" }}>
            {message}
          </p>
        )}
      </section>
    </div>
  );
}
