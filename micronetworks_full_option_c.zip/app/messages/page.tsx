import MessagesView from "./MessagesView";

export default function MessagesPage() {
  return (
    <div style={{ maxWidth: 1040, margin: "0 auto", padding: "24px 16px" }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>
        Messages
      </h1>
      <MessagesView />
    </div>
  );
}
