"use client";

import { useEffect, useState } from "react";

export default function MessagesView() {
  const [threads, setThreads] = useState<any[]>([]);
  const [selectedPartner, setSelectedPartner] = useState<any | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState("");

  useEffect(() => {
    async function loadThreads() {
      const res = await fetch("/api/messages/threads");
      const data = await res.json();
      setThreads(data.threads || []);
    }
    loadThreads();
  }, []);

  useEffect(() => {
    if (!selectedPartner) return;
    async function loadMessages() {
      const res = await fetch(`/api/messages/thread?partnerId=${selectedPartner.id}`);
      const data = await res.json();
      setMessages(data.messages || []);
    }
    loadMessages();
  }, [selectedPartner]);

  async function send() {
    if (!input.trim() || !selectedPartner) return;
    await fetch("/api/messages/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        receiverAccountId: selectedPartner.id,
        content: input.trim()
      })
    });
    setInput("");
    const res = await fetch(`/api/messages/thread?partnerId=${selectedPartner.id}`);
    const data = await res.json();
    setMessages(data.messages || []);
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "minmax(0,0.9fr) minmax(0,1.4fr)",
        gap: 16,
        marginTop: 8
      }}
    >
      <div
        style={{
          borderRadius: 16,
          border: "1px solid rgba(30,64,175,0.7)",
          background: "#020617",
          padding: 8,
          maxHeight: 460,
          overflowY: "auto"
        }}
      >
        {threads.length === 0 && (
          <p style={{ fontSize: 13, color: "#9ca3af" }}>
            No conversations yet.
          </p>
        )}
        {threads.map((t) => (
          <button
            key={t.partner.id}
            onClick={() => setSelectedPartner(t.partner)}
            style={{
              width: "100%",
              textAlign: "left",
              padding: 8,
              borderRadius: 10,
              border: "none",
              background:
                selectedPartner?.id === t.partner.id
                  ? "rgba(30,64,175,0.6)"
                  : "transparent",
              cursor: "pointer"
            }}
          >
            <div style={{ fontSize: 13, fontWeight: 600 }}>
              @{t.partner.username}
            </div>
            <div
              style={{
                fontSize: 11,
                color: "#9ca3af",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis"
              }}
            >
              {t.last_message}
            </div>
          </button>
        ))}
      </div>
      <div
        style={{
          borderRadius: 16,
          border: "1px solid rgba(30,64,175,0.7)",
          background: "#020617",
          padding: 10,
          display: "flex",
          flexDirection: "column",
          minHeight: 320
        }}
      >
        {selectedPartner ? (
          <>
            <div
              style={{
                marginBottom: 8,
                fontSize: 13,
                fontWeight: 600,
                borderBottom: "1px solid rgba(15,23,42,0.9)",
                paddingBottom: 4
              }}
            >
              Chat with @{selectedPartner.username}
            </div>
            <div
              style={{
                flex: 1,
                overflowY: "auto",
                display: "flex",
                flexDirection: "column",
                gap: 6,
                paddingRight: 4,
                maxHeight: 360
              }}
            >
              {messages.map((m) => (
                <div
                  key={m.id}
                  style={{
                    alignSelf: m.isMine ? "flex-end" : "flex-start",
                    background: m.isMine ? "#2563eb" : "#020617",
                    color: m.isMine ? "white" : "#e5e7eb",
                    border: "1px solid rgba(15,23,42,0.9)",
                    borderRadius: 16,
                    padding: "6px 10px",
                    fontSize: 13,
                    maxWidth: "80%"
                  }}
                >
                  {m.content}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a message..."
                style={{
                  flex: 1,
                  padding: 8,
                  borderRadius: 999,
                  border: "1px solid rgba(15,23,42,0.9)",
                  background: "#020617",
                  color: "#e5e7eb",
                  fontSize: 13
                }}
              />
              <button
                onClick={send}
                style={{
                  padding: "6px 14px",
                  borderRadius: 999,
                  border: "none",
                  background: "#2563eb",
                  color: "white",
                  fontSize: 13,
                  cursor: "pointer"
                }}
              >
                Send
              </button>
            </div>
          </>
        ) : (
          <p style={{ fontSize: 13, color: "#9ca3af" }}>
            Select a conversation from the left.
          </p>
        )}
      </div>
    </div>
  );
}
